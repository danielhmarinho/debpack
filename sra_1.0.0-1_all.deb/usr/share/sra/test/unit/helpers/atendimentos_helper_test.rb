# -*- encoding : utf-8 -*-
require 'test_helper'

class AtendimentosHelperTest < ActionView::TestCase
end
