FactoryGirl.define do

  factory :type, :class => Type do
    name "Documentacao"

  end
end