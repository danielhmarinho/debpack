FactoryGirl.define do

  factory :place, :class => Place do
    name "Place1"

  end
end